// script.js - Lector dual QR + Códigos de barra
// Configuración: pega aquí tu URL de Apps Script (doPost)
const APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbyT6bOSZCyqxPjPJdwlql5Z9mZfxNk5UIP7TPZ37aDd3-t4svXCYQg5JwBkH9kCnJWR/exec";

const codeReader = new ZXing.BrowserMultiFormatReader();
const video = document.getElementById('video');
const overlay = document.getElementById('overlay');
const startBtn = document.getElementById('startBtn');
const sendBtn = document.getElementById('sendBtn');
const status = document.getElementById('status');
const inputCodigo = document.getElementById('codigo');
const inputNombre = document.getElementById('nombre');
const inputEstado = document.getElementById('estado');

let currentDeviceId = null;
let scanning = false;

async function startCamera() {
  try {
    status.textContent = '';
    const devices = await codeReader.listVideoInputDevices();
    if (!devices || devices.length === 0) {
      overlay.textContent = 'No se detectó cámara';
      return;
    }
    // prefer rear camera if available
    const rear = devices.find(d => /back|rear|environment/i.test(d.label)) || devices[0];
    currentDeviceId = rear.deviceId;

    // start continuous decode
    await codeReader.decodeFromVideoDevice(currentDeviceId, 'video', (result, err) => {
      if (result) {
        onDetected(result.text);
      }
      // ignore NotFoundException errors
    });
    scanning = true;
    startBtn.textContent = 'Detener cámara';
    overlay.textContent = 'Escaneando... apunte al código';
  } catch (e) {
    console.error(e);
    overlay.textContent = 'Error al iniciar cámara: ' + (e.message || e);
  }
}

function stopCamera() {
  try {
    codeReader.reset();
  } catch(e){}
  scanning = false;
  startBtn.textContent = 'Iniciar cámara';
  overlay.textContent = 'Escaneo detenido';
}

function onDetected(text) {
  // fill code field and show status
  inputCodigo.value = text;
  overlay.textContent = 'Código detectado';
  status.textContent = 'Código: ' + text;
  // optional: auto-send if name present -- comment out to require manual send
  // if (inputNombre.value.trim()) sendRecord();
}

startBtn.addEventListener('click', () => {
  if (scanning) {
    stopCamera();
  } else {
    startCamera();
  }
});

sendBtn.addEventListener('click', () => {
  sendRecord();
});

async function sendRecord() {
  const codigo = inputCodigo.value.trim();
  const nombre = inputNombre.value.trim();
  const estado = inputEstado.value;
  if (!codigo) { alert('Primero escanea un código.'); return; }
  if (!nombre) { alert('Ingrese su nombre en el campo Nombre del técnico.'); return; }

  const payload = { codigo, nombre, estado };
  status.textContent = 'Enviando registro...';

  try {
    // Use no-cors because Apps Script sometimes blocks direct CORS; request will still reach server
    await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    status.textContent = '✅ Registro enviado';
    // clear code for next scan but keep name
    inputCodigo.value = '';
    setTimeout(()=>{ status.textContent=''; }, 2000);
  } catch (err) {
    console.error(err);
    status.textContent = 'Error al enviar registro';
  }
}

// auto-start camera on load? No, wait for user action for permission on mobile
// window.addEventListener('load', () => {});
